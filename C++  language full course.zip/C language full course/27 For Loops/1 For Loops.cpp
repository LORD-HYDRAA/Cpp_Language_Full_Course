#include <stdio.h>

int
main(){
// for loop = repeats a section of code a limited amount of times

for(int i = 1; i <= 10; i++)
{
printf("%d\n", i);
}

return 0;

}