#include <stdio.h>

int main(){

// constant = fixed value that cannot be altered by the program during its execution

const float PI = 3.14159;

printf("%f", PI);


return 0;

}