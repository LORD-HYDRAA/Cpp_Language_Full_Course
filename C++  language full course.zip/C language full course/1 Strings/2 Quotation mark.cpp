#include <stdio.h>
int main() {
   
   printf("\"Hello World\"");
   printf("\n");
   printf("\n\\Hello World\\");
   return 0;
}


/*
    Whenever we have to use quotation mark in string we have to put backslash between that word or string

    same for all symbols

*/

