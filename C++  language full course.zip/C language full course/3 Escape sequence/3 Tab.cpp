#include <stdio.h>
int main() {
   
   printf("1\t2\t3\t");
   return 0;
}