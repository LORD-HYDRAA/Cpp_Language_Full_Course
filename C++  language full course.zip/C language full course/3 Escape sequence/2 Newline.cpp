#include <stdio.h>
int main() {
   
   printf(" One \n Two\n Three\n");
   return 0;
}
