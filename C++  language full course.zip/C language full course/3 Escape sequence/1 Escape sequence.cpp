/* 

                        escape sequence = character combination consisting of a backslash \ 
                                          followed by a letter or combination of digits.
                                          They specify actions within a line or string of text.
                                          \n = newline
                                           \t = tab

*/