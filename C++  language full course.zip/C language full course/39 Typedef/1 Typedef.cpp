#include <stdio.h>
#include <string.h>



typedef struct
{
char name[25];
char password[25];
char id[25];
} User;

int main()
{
        // typedef = reserved keyword that gives an existing datatype a "nickname"


User user1 = {"User = Bro", "password = 123","ID = 123456789"};
User user2 = {"User = Bruh", "password = 321","ID = 987654321"};

printf("%s\n", user1.name);
printf("%s\n", user1.password);
printf("%s\n", user1.id);
printf("\n");
printf("%s\n", user2.name);
printf("%s\n", user2.password);
printf("%s\n", user2.id);

return 0;

}