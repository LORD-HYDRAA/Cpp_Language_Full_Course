#include <stdio.h>

int main(){

char calculation;
double num1;
double num2;
double result;

printf("\nEnter an operator (+ - * /):" ,"\t");
scanf("%c", &calculation);


printf("Enter number 1: ");
scanf("%lf", &num1);

printf("Enter number 2: ");
scanf("%lf", &num2);

switch(calculation){
   case '+':
      result = num1 + num2;
      printf("\nresult: %lf", result);
      break;
    case '-':
       result = num1 + num2;
       printf("\nresult: %lf", result);
       break;
    case '*':
       result = num1 + num2;
       printf("\nresult: %lf", result);
       break;
    case '/':
       result = num1 + num2;
       printf("\nresult: %lf", result);
       break;
    default:
       printf("%c is not valid", calculation);

}

return 0;

}