#include<stdio.h>


void birthday()

{

printf("\nHappy birthday to you!");
printf("\nHappy birthday to you!");
printf("\nHappy birthday dear...YOU!");
printf("\nHappy birthday to you!\n");

}

int main(){

birthday();
birthday();
birthday();

return 0;

}