#include <stdio.h>

int main(){

                // arithmetic operators

                                      // (subtraction)
                                     // + (addition)
                                    // * (multiplication)
                                   // / (division)
                                  // % (modulus)
                                 // ++ increment
                                // decrement

int x = 5;
int y = 2;

//int z = x + y;
//int z = x - y;
//int z = x * y;
//float z = x / (float) y;
//int z = x % y;

x++;

y--;

printf("%d", y);
printf("%d", x);

return 0;

}